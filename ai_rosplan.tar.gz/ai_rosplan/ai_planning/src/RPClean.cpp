#include "ai_planning/RPClean.h"

namespace KCL_rosplan {

    // constructor
    RPClean::RPClean(ros::NodeHandle &nh) {
        nh_ = nh;
    }

    bool RPClean::concreteCallback(const rosplan_dispatch_msgs::ActionDispatch::ConstPtr& msg) {
        ros::Publisher velocity_publisher = nh_.advertise<geometry_msgs::Twist>("/cmd_vel_mux/input/navi",1); 
        geometry_msgs::Twist velocidad;

        ros::Rate rate(4);
        velocidad.angular.z=1;

        for (int i=0;i<=16;i++){

            velocity_publisher.publish(velocidad);
            rate.sleep();

        }

        return true;
    }
    
} // close namespace

int main(int argc, char **argv) {

    ros::init(argc, argv, "rosplan_interface_clean");

    ros::NodeHandle nh("~");

    // create PDDL action subscriber
    KCL_rosplan::RPClean rpmb(nh);

    rpmb.runActionInterface();

    return 0;
}
